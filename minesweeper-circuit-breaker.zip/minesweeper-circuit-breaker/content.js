(function () {
  "use strict";

  const DEFAULTS = { frictionSeconds: 10, dailyMinutes: 60, gateOtherGames: true };

  const OTHER_GAME_QUERY =
    /\b(snake( game)?|tic[ -]?tac[ -]?toe|solitaire|pac[ -]?man|memory game|flappy|2048|sudoku|spinner)\b/i;

  const hostName = location.hostname;
  const onGoogle = /(^|\.)google\./.test(hostName) && /\/search/.test(location.pathname);
  const onMsSite = /(^|\.)minesweeper\.online$|(^|\.)minesweeperonline\.com$/.test(hostName);
  if (!onGoogle && !onMsSite) return;

  // ---------- helpers ----------
  const dateStr = () => {
    const d = new Date(); // local date, so the reset happens at your local midnight
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  };
  const playKey = () => "playtime-" + dateStr();
  const fmt = (ms) => {
    const s = Math.max(0, Math.ceil(ms / 1000));
    return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
  };
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };

  // ---------- overlay UI ----------
  let overlayOpen = false;
  let blocked = false;
  const unlocked = { minesweeper: false, game: false };

  function buildHost(id) {
    const host = document.createElement("div");
    host.id = id;
    host.style.cssText = "all: initial; position: fixed; inset: 0; z-index: 2147483647;";
    const shadow = host.attachShadow({ mode: "open" });
    (document.documentElement || document.body).appendChild(host);
    return { host, shadow };
  }

  function lockScroll(on) {
    const v = on ? "hidden" : "";
    if (document.documentElement) document.documentElement.style.overflow = v;
    if (document.body) document.body.style.overflow = v;
  }

  const baseStyle = `
    :host { all: initial; }
    .wrap { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center;
      background: rgba(20,12,14,0.94); backdrop-filter: blur(6px);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    .card { background:#1e1618; color:#f3ece9; border-radius:16px; padding:32px 28px; max-width:380px; width:90%;
      box-shadow:0 20px 60px rgba(0,0,0,0.5); text-align:center; border:1px solid rgba(255,255,255,0.08); }
    h1 { font-size:20px; margin:0 0 8px; }
    p { font-size:14px; line-height:1.5; color:#cbb; margin:0 0 16px; opacity:0.85; }
    .left { display:inline-block; background:rgba(255,255,255,0.07); border-radius:8px; padding:4px 10px; font-weight:700; margin-bottom:14px; }
    textarea { width:100%; box-sizing:border-box; min-height:60px; border-radius:10px;
      border:1px solid rgba(255,255,255,0.15); background:rgba(255,255,255,0.05); color:#fff;
      padding:10px; font-size:13px; resize:none; margin-bottom:14px; }
    button { border:none; border-radius:10px; padding:10px 16px; font-size:14px; font-weight:600;
      cursor:pointer; width:100%; margin-top:8px; }
    .primary { background:#b22234; color:white; }
    .primary:disabled { background:#5a3238; color:#a89093; cursor:not-allowed; }
    .secondary { background:transparent; color:#cbb; text-decoration:underline; }
    .timer { font-variant-numeric: tabular-nums; font-weight:700; }
    .note { font-size:11px; color:#a89093; margin-top:10px; opacity:0.7; }
  `;

  function leave() { location.href = "https://www.google.com"; }

  function closeOverlay() {
    const h = document.getElementById("__ms_blocker_host");
    if (h) h.remove();
    overlayOpen = false;
    lockScroll(false);
  }

  function showHardBlock(limitMin) {
    blocked = true;
    overlayOpen = true;
    removeBadge();
    lockScroll(true);
    const { shadow } = buildHost("__ms_blocker_host");
    shadow.innerHTML = `
      <style>${baseStyle}</style>
      <div class="wrap"><div class="card">
        <h1>Time's up \u26D4</h1>
        <p>You've used all ${limitMin} minutes of Minesweeper for today. It resets at midnight.</p>
        <button class="primary" id="leave">Take me back to Google</button>
      </div></div>`;
    shadow.getElementById("leave").addEventListener("click", leave);
  }

  function showFriction(seconds, leftMs, onPass) {
    overlayOpen = true;
    lockScroll(true);
    const { shadow } = buildHost("__ms_blocker_host");
    shadow.innerHTML = `
      <style>${baseStyle}</style>
      <div class="wrap"><div class="card">
        <h1>Wait a sec \u23F3</h1>
        <div class="left">${fmt(leftMs)} left today</div>
        <p>Type a quick reason you actually want to play right now. Button unlocks in <span class="timer" id="t">${seconds}</span>s.</p>
        <textarea id="reason" placeholder="Why right now?"></textarea>
        <button class="primary" id="go" disabled>Let me play</button>
        <button class="secondary" id="no">Actually, never mind</button>
        <div class="note">Your reason may be shared to a linked Discord channel.</div>
      </div></div>`;

    const timerEl = shadow.getElementById("t");
    const goBtn = shadow.getElementById("go");
    const reasonEl = shadow.getElementById("reason");
    let remaining = seconds;

    const update = () => { goBtn.disabled = !(remaining <= 0 && reasonEl.value.trim().length >= 3); };
    const tick = setInterval(() => {
      remaining -= 1;
      timerEl.textContent = String(Math.max(remaining, 0));
      if (remaining <= 0) { clearInterval(tick); update(); }
    }, 1000);

    reasonEl.addEventListener("input", update);
    goBtn.addEventListener("click", () => {
      clearInterval(tick);
      onPass(reasonEl.value.trim());
      closeOverlay();
    });
    shadow.getElementById("no").addEventListener("click", () => { clearInterval(tick); leave(); });
  }

  // ---------- on-screen countdown badge ----------
  let badgeEl = null;
  function ensureBadge() {
    if (badgeEl && badgeEl.isConnected) return badgeEl;
    const host = document.createElement("div");
    host.id = "__ms_blocker_badge";
    host.style.cssText = "all: initial; position: fixed; right: 16px; bottom: 16px; z-index: 2147483646; pointer-events: none;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        .pill { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; font-size:13px; font-weight:700;
          background:rgba(30,22,24,0.92); color:#f3ece9; border:1px solid rgba(255,255,255,0.15);
          border-radius:999px; padding:7px 14px; box-shadow:0 4px 16px rgba(0,0,0,0.35); font-variant-numeric:tabular-nums; }
        .pill.low { background:#b22234; border-color:#ff8a98; }
      </style>
      <div class="pill" id="pill"></div>`;
    (document.documentElement || document.body).appendChild(host);
    badgeEl = host;
    return host;
  }
  function updateBadge(leftMs) {
    const host = ensureBadge();
    const pill = host.shadowRoot.getElementById("pill");
    pill.textContent = "\u23F1 " + fmt(leftMs) + " left today";
    pill.classList.toggle("low", leftMs <= 5 * 60 * 1000);
    host.style.display = "block";
  }
  function hideBadge() { if (badgeEl) badgeEl.style.display = "none"; }
  function removeBadge() { if (badgeEl) { badgeEl.remove(); badgeEl = null; } }

  // ---------- Discord report ----------
  function reportReason(reason, usedMs, limitMin) {
    try {
      chrome.runtime.sendMessage({
        type: "ms-reason", reason, url: location.href, timestamp: new Date().toISOString(),
        usedMin: Math.round(usedMs / 60000), limitMin
      });
    } catch (e) { /* ignore */ }
  }

  // ---------- detection ----------
  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  // Is the word "Minesweeper" visibly on the page (game title / picker)? Ignores the search box + autocomplete.
  function minesweeperWidgetPresent() {
    const root = document.body;
    if (!root) return false;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (!/minesweeper/i.test(node.nodeValue)) continue;
      const el = node.parentElement;
      if (!el) continue;
      if (el.closest('script, style, noscript, textarea, input, [role="listbox"], [role="combobox"], [role="search"]')) continue;
      if (!isVisible(el)) continue;
      return true;
    }
    return false;
  }

  const queryHasMs = () => /minesweeper/i.test(new URLSearchParams(location.search).get("q") || "");

  // ---------- play clock ----------
  let clockStarted = false;
  function startPlayClock(limitMin) {
    if (clockStarted) return;
    clockStarted = true;
    const limitMs = limitMin * 60000;

    const id = setInterval(() => {
      if (!alive()) { clearInterval(id); return; }
      if (blocked) { clearInterval(id); return; }

      // Only count while the tab is visible and Minesweeper is actually on screen.
      const playing = document.visibilityState === "visible" &&
        (onMsSite || queryHasMs() || minesweeperWidgetPresent());
      const key = playKey();

      chrome.storage.local.get({ [key]: 0, lastTick: 0 }, (d) => {
        let used = d[key] || 0;
        if (playing) {
          const now = Date.now();
          const delta = now - d.lastTick;
          // Dedupe: if another frame/tab already counted within the last ~second, skip.
          if (delta >= 800) {
            used += Math.min(delta, 1500);
            chrome.storage.local.set({ [key]: used, lastTick: now });
          }
        }
        if (used >= limitMs) {
          clearInterval(id);
          showHardBlock(limitMin);
        } else if (playing && !overlayOpen) {
          updateBadge(limitMs - used);
        } else if (!playing) {
          hideBadge();
        }
      });
    }, 1000);
  }

  // ---------- gate ----------
  function gate(kind) {
    if (overlayOpen || blocked || unlocked[kind]) return;
    overlayOpen = true; // reserve immediately while storage loads
    chrome.storage.sync.get(DEFAULTS, (settings) => {
      const key = playKey();
      chrome.storage.local.get({ [key]: 0 }, (data) => {
        const used = data[key] || 0;
        const limitMs = settings.dailyMinutes * 60000;
        if (used >= limitMs) {
          showHardBlock(settings.dailyMinutes);
        } else {
          showFriction(settings.frictionSeconds, limitMs - used, (reason) => {
            // One prompt per page load: passing for any game unlocks the page,
            // and the play clock runs whenever Minesweeper is actually on screen.
            unlocked.minesweeper = true;
            unlocked.game = true;
            startPlayClock(settings.dailyMinutes);
            reportReason(reason, used, settings.dailyMinutes);
          });
        }
      });
    });
  }

  function check() {
    if (onMsSite || queryHasMs() || minesweeperWidgetPresent()) gate("minesweeper");
  }

  function checkOtherGameQuery() {
    chrome.storage.sync.get(DEFAULTS, (s) => {
      const q = new URLSearchParams(location.search).get("q") || "";
      if (s.gateOtherGames && OTHER_GAME_QUERY.test(q) && !/minesweeper/i.test(q)) gate("game");
    });
  }

  check();
  if (onGoogle) checkOtherGameQuery();

  let timer = null;
  const schedule = () => {
    if (timer) return;
    timer = setTimeout(() => { timer = null; if (!unlocked.minesweeper) check(); }, 400);
  };
  const startObserver = () => {
    new MutationObserver(schedule).observe(document.documentElement, {
      childList: true, subtree: true, attributes: true, characterData: true
    });
  };
  if (document.documentElement) startObserver();
  else document.addEventListener("DOMContentLoaded", startObserver, { once: true });
})();
