// ====== EDIT THESE TWO LINES BEFORE SHARING THE EXTENSION ======
const BOT_URL = "https://minesweeper-logs-production.up.railway.app/minesweeper";
const BOT_SECRET = "aSDASDFASFASFAS";
// ===============================================================
