importScripts("config.js");

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "ms-reason") return;
  chrome.storage.sync.get({ webhookUrl: "", displayName: "", botUrl: "", botSecret: "" }, async (s) => {
    const site = msg.url.includes("google.") ? "Google Minesweeper" : "minesweeper.online";

    // 1) Prefer your bot's endpoint (runs on Railway)
    const botUrl = s.botUrl || BOT_URL;
    const botSecret = s.botSecret || BOT_SECRET;
    if (botUrl && !botUrl.includes("YOUR-APP")) {
      try {
        const res = await fetch(botUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-secret": botSecret },
          body: JSON.stringify({
            name: s.displayName, reason: msg.reason, site,
            usedMin: msg.usedMin, limitMin: msg.limitMin
          })
        });
        if (res.ok) { sendResponse({ ok: true, via: "bot" }); return; }
      } catch (e) { /* fall through to webhook */ }
    }

    // 2) Fallback: plain Discord webhook
    if (s.webhookUrl) {
      const who = s.displayName ? `**${s.displayName}**` : "Someone";
      const usage = typeof msg.usedMin === "number" ? ` (${msg.usedMin}/${msg.limitMin} min used today)` : "";
      try {
        const res = await fetch(s.webhookUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            content: `\u26CF\uFE0F ${who} just unlocked ${site}${usage}.\n> ${msg.reason}`,
            allowed_mentions: { parse: [] }
          })
        });
        sendResponse({ ok: res.ok, via: "webhook" });
        return;
      } catch (e) { /* ignore */ }
    }
    sendResponse({ ok: false });
  });
  return true;
});
