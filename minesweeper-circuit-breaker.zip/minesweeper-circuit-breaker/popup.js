const DEFAULTS = { dailyMinutes: 60 };
const d = new Date();
const key = "playtime-" + d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
chrome.storage.sync.get(DEFAULTS, (s) => {
  chrome.storage.local.get({ [key]: 0 }, (r) => {
    const usedMin = Math.floor((r[key] || 0) / 60000);
    document.getElementById("count").textContent = usedMin + " / " + s.dailyMinutes + " min";
  });
});
document.getElementById("openOptions").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
