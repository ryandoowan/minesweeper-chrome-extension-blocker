const DEFAULTS = { frictionSeconds: 10, dailyMinutes: 60, gateOtherGames: true, webhookUrl: "", displayName: "", botUrl: "", botSecret: "" };
const todayKey = () => { const d = new Date(); return "playtime-" + d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS, (s) => {
  $("friction").value = s.frictionSeconds;
  $("max").value = s.dailyMinutes;
  $("gateOther").checked = s.gateOtherGames;
  $("webhook").value = s.webhookUrl;
  $("botUrl").value = s.botUrl;
  $("botSecret").value = s.botSecret;
  $("displayName").value = s.displayName;
});

$("save").addEventListener("click", () => {
  chrome.storage.sync.set({
    frictionSeconds: Math.max(0, parseInt($("friction").value, 10) || 0),
    dailyMinutes: Math.max(0, parseInt($("max").value, 10) || 0),
    gateOtherGames: $("gateOther").checked,
    webhookUrl: $("webhook").value.trim(),
    botUrl: $("botUrl").value.trim(),
    botSecret: $("botSecret").value.trim(),
    displayName: $("displayName").value.trim()
  }, () => {
    $("saved").style.opacity = "1";
    setTimeout(() => ($("saved").style.opacity = "0"), 1500);
  });
});

$("testWebhook").addEventListener("click", () => {
  const r = $("testResult");
  const url = $("webhook").value.trim();
  const show = (t, cls) => { r.textContent = t; r.className = cls; r.style.opacity = "1"; };
  const botUrl = $("botUrl").value.trim() || BOT_URL;
  if (botUrl && !botUrl.includes("YOUR-APP")) {
    return fetch(botUrl, { method: "POST", headers: { "Content-Type": "application/json", "x-secret": $("botSecret").value.trim() || BOT_SECRET },
      body: JSON.stringify({ name: $("displayName").value.trim(), reason: "test message - connection works", site: "test", usedMin: 0, limitMin: 60 }) })
      .then((res) => show(res.ok ? "Bot OK \u2713" : "Failed (" + res.status + ")", res.ok ? "ok" : "err"))
      .catch((e) => show("Error: " + e, "err"));
  }
  if (!url) return show("Add a bot URL or webhook first", "err");
  const name = $("displayName").value.trim();
  fetch(url, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content: `\u2705 ${name ? "**" + name + "**'s" : "Your"} Minesweeper Circuit Breaker is connected.` }) })
    .then((res) => show(res.ok ? "Sent \u2713" : "Failed (" + res.status + ")", res.ok ? "ok" : "err"))
    .catch((e) => show("Error: " + e, "err"));
});

$("resetToday").addEventListener("click", () => {
  chrome.storage.local.set({ [todayKey()]: 0 }, () => {
    const b = $("resetToday"), o = b.textContent;
    b.textContent = "Reset \u2713";
    setTimeout(() => (b.textContent = o), 1200);
  });
});
